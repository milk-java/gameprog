extends Node2D

var num_asteroids: int = 10
const ASTEROID_SCENE: PackedScene = preload("res://Asteroid.tscn")

func _ready(): 
	for n in range(num_asteroids):
		var new_asteroid = ASTEROID_SCENE.instantiate()
		new_asteroid.position = get_random_position()
		add_child(new_asteroid)

func get_random_position() -> Vector2:
	var screen_size = get_viewport_rect().size
	return Vector2(randf_range(0, screen_size.x), randf_range(0, screen_size.y))
