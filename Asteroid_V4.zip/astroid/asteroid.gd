extends Area2D
var velocity = Vector2.ZERO
@export var speed: float= 150.0
func _ready():
	randomize()
	var x = randf_range(-100,100)
	var y = randf_range(-100,100)
	velocity = Vector2(x,y).normalized() *speed
	
func _process(delta):
	position += velocity *delta
	_wrap_around()


func _wrap_around():
	var screen_size: Vector2 = get_viewport_rect().size
	position.x = wrapf(position.x, 0.0, screen_size.x)
	position.y = wrapf(position.y, 0.0, screen_size.y)


func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("Laser"):
		queue_free()
		area.queue_free()
		get_parent().add_points(10)
	elif area.is_in_group("Player"):
		queue_free()
		get_parent().lose_health()
	pass # Replace with function body.
