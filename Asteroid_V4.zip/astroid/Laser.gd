extends Area2D
class_name Laser

@export var speed = 500

func _process(delta: float) -> void:
	position += transform.x * speed *delta
	


func _on_area_entered(area: Area2D) -> void:
	if not(area is Laser): 
		area.queue_free()
		queue_free()
		get_parent().add_points(10)
	pass # Replace with function body.


func _on_bullet_timer_timeout() -> void:
	queue_free()
	pass # Replace with function body.
