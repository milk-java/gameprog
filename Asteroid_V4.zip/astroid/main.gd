extends Node2D

const ASTEROID_SCENE: PackedScene = preload("res://Asteroid.tscn")
const laser: PackedScene = preload("res://laser.tscn")

@export var spawn_interval: float = 2.0   # time between spawns
@export var max_asteroids: int = 100
@export var start_health: int = 3


var current_asteroids: int = 0
var health : int
var points: int

func _ready():
	reset_game()
	
	$AsteroidTimer.wait_time = spawn_interval
	$AsteroidTimer.start()
	$AsteroidTimer.timeout.connect(_on_AsteroidTimer_timeout)
func reset_game():
	health= start_health
	points= 0
	_update_hud()
	
func _on_AsteroidTimer_timeout():
	if current_asteroids < max_asteroids:
		spawn_asteroid()
		current_asteroids += 1

func spawn_asteroid():
	var asteroid = ASTEROID_SCENE.instantiate()
	asteroid.position = get_random_position()
	add_child(asteroid)

func get_random_position() -> Vector2:
	var screen_size = get_viewport_rect().size
	return Vector2(randf_range(0, screen_size.x), randf_range(0, screen_size.y))
	
func _process(delta: float) -> void:
	if Input.is_action_just_pressed("fire"):
		var new_laser = laser.instantiate()
		new_laser.position= $Player.position 
		new_laser.rotation = $Player.rotation 
		add_child(new_laser)
		
		
func add_points(value:int):
	points+= value
	_update_hud()
	
func _update_hud():
	$HUD.update_health(health)
	$HUD.update_score(points)
	
func _on_game_over():
	Global.last_score = points 
	get_tree().change_scene_to_file("res://game_over.tscn")
	
func lose_health():
	health -=1
	_update_hud()
	if health <=0:
		_on_game_over()
