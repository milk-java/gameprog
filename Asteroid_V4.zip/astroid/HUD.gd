extends CanvasLayer

func update_health(value:int) -> void:
	$HealthLabel.text = "Health: %d" % value
	
func update_score(value: int) -> void:
	$ScoreLabel.text = "Score: %d" % value
	
