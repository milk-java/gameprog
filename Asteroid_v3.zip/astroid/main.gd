extends Node2D

const ASTEROID_SCENE: PackedScene = preload("res://Asteroid.tscn")

@export var spawn_interval: float = 2.0   # time between spawns
@export var max_asteroids: int = 10
var current_asteroids: int = 0

func _ready():
	$AsteroidTimer.wait_time = spawn_interval
	$AsteroidTimer.start()
	$AsteroidTimer.timeout.connect(_on_AsteroidTimer_timeout)

func _on_AsteroidTimer_timeout():
	if current_asteroids < max_asteroids:
		spawn_asteroid()
		current_asteroids += 1

func spawn_asteroid():
	var asteroid = ASTEROID_SCENE.instantiate()
	asteroid.position = get_random_position()
	add_child(asteroid)

func get_random_position() -> Vector2:
	var screen_size = get_viewport_rect().size
	return Vector2(randf_range(0, screen_size.x), randf_range(0, screen_size.y))
