extends Area2D

@export var rotate_speed:float = 5

var velocity =Vector2.ZERO
func _process(delta):
	#get input
	var rot = Input.get_axis("left","right")*10
	rotate(rot * delta)
	if Input.is_action_pressed("back"):
		
		velocity= lerp(velocity,-transform.x *300,1*delta)
		
	if Input.is_action_pressed("thrust"):
		#thrust
		velocity= lerp(velocity,transform.x *300,1*delta)
	position += velocity*delta 
	velocity= lerp(velocity,Vector2.ZERO, 1*delta)
	pass
	
