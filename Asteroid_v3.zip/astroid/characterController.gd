extends CharacterBody2D
@export var thrust_foward : float = 500.0
@export var thrust_back: float= 400.0
@export var rotation_speed : float = 5.0
@export var inertia: float= 0.99
@export var max_speed: float = 700.0

func _physics_process(delta: float) -> void:
	var rot = Input.get_axis("left","right")
	rotation+= rot *rotation_speed *delta
	
	if Input.is_action_pressed("thrust"):
		velocity += transform.x *thrust_foward *delta
		
	if Input.is_action_pressed("back"):
		velocity += -transform.x *thrust_back *delta
	if velocity.length() >max_speed:
		velocity= velocity.normalized() *max_speed
	
	
	velocity *= inertia
	move_and_slide()
	_wrap_around()


func _wrap_around():
	var screen_size: Vector2 = get_viewport_rect().size
	position.x = wrapf(position.x, 0.0, screen_size.x)
	position.y = wrapf(position.y, 0.0, screen_size.y)
